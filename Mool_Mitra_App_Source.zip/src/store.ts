// App state: one object, saved in this browser only (simulated data, nothing leaves the device).
import { useSyncExternalStore } from 'react';
import type { Attrs } from './catalog';
import type { Goal, Tier } from './model';

export type Lang = 'en' | 'hi';
export type Step = 'calc' | 'signup' | 'costs' | 'product' | 'price' | 'launch' | 'live';
export type Tab = 'home' | 'hisaab' | 'alerts' | 'listing';

export interface WeekRow { week: number; price: number; shown: number; orders: number; kept: number; returned: number; profit: number; launch: boolean; festive: boolean }
export interface Alert { id: string; week: number; kind: 'rival' | 'festive' | 'returns' | 'slow'; status: 'new' | 'accepted' | 'ignored'; price?: number }

export interface State {
  lang: Lang;
  step: Step;
  tab: Tab;
  calc: { attrs: Attrs; cost: number };
  profile: { name: string; shop: string; city: string; mobile: string; pack: number; buyers: 'local' | 'state' | 'india' };
  product: { attrs: Attrs; cost: number; tier: Tier; sizeChart: boolean; stock: number };
  goal: Goal;
  price: number;
  launch: boolean;
  mode: 'ask' | 'auto';
  week: number;
  weeks: WeekRow[];
  alerts: Alert[];
  launchLeft: number;
  nudged: string[];
}

const KEY = 'mool-mitra-v1';
export const initial = (): State => ({
  lang: 'en', step: 'calc', tab: 'home',
  calc: { attrs: {}, cost: 0 },
  profile: { name: 'Ramesh Gupta', shop: 'Gupta Chikan Kendra', city: 'Lucknow', mobile: '98XXX XX123', pack: 8, buyers: 'india' },
  product: { attrs: {}, cost: 0, tier: 'better', sizeChart: false, stock: 300 },
  goal: 'profit', price: 0, launch: true, mode: 'ask', week: 0, weeks: [], alerts: [], launchLeft: 20, nudged: [],
});

function load(): State {
  try { const raw = localStorage.getItem(KEY); if (raw) return { ...initial(), ...JSON.parse(raw) }; } catch { /* storage unavailable */ }
  return initial();
}
let state: State = load();
const subs = new Set<() => void>();
export function getState() { return state; }
export function update(fn: (draft: State) => void) {
  const next: State = structuredClone(state);
  fn(next);
  state = next;
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ }
  subs.forEach(f => f());
}
export function reset() { update(d => { Object.assign(d, initial(), { lang: d.lang }); }); }
export function useStore() {
  return useSyncExternalStore(cb => { subs.add(cb); return () => subs.delete(cb); }, () => state);
}
export const L = (s: { lang: Lang }, en: string, hi: string) => (s.lang === 'hi' ? hi : en);
export const inr = (n: number) => (n < 0 ? '−₹' : '₹') + Math.abs(Math.round(n)).toLocaleString('en-IN');
