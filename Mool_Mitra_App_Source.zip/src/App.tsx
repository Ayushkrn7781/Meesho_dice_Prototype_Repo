import { useEffect, useState } from 'react';
import { District } from './District';
import { SellerApp } from './seller/SellerApp';
import { reset, useStore } from './store';
import { Logo } from './ui';

type Route = 'home' | 'seller' | 'district';
const read = (): Route => { const h = location.hash.replace('#', ''); return h === 'seller' || h === 'district' ? h : 'home'; };

export function App() {
  const [route, setRoute] = useState<Route>(read);
  useEffect(() => { const f = () => setRoute(read()); addEventListener('hashchange', f); return () => removeEventListener('hashchange', f); }, []);
  return (<>
    <nav className="top">
      <a href="#home" className="brand"><Logo size={30} /><span>Mool Mitra</span></a>
      <div className="links">
        <a href="#home" className={route === 'home' ? 'on' : ''}>Overview</a>
        <a href="#seller" className={route === 'seller' ? 'on' : ''}>Seller app</a>
        <a href="#district" className={route === 'district' ? 'on' : ''}>District console</a>
      </div>
    </nav>
    {route === 'home' && <Landing />}
    {route === 'seller' && <SellerPage />}
    {route === 'district' && <main className="wrap"><District /></main>}
    <footer className="foot">Mool Mitra · Team Razor Blade, IIT Kanpur · Meesho DICE Challenge S3 · concept product, all data simulated</footer>
  </>);
}

function Landing() {
  return (
    <main className="land">
      <section className="land-hero">
        <div>
          <p className="kicker light">For new-to-online sellers on Meesho</p>
          <h1>The right first price,<br />from your own cost.</h1>
          <p className="lead">Half of new sellers lose money on a listing because they copy the cheapest rival or use their shop price. Mool Mitra prices in returns, failed deliveries, shipping and fees, then stays with the seller as the product grows.</p>
          <div className="land-cta"><a className="cta inline" href="#seller">Try the seller app →</a><a className="btn light" href="#district">Open district console</a></div>
        </div>
        <div className="land-nums">
          <div><b>−₹83</b><span>per order when a ₹180 kurti copies a ₹199 rival</span></div>
          <div><b>₹321</b><span>its real breakeven after RTO, returns and shipping</span></div>
          <div><b>+₹53</b><span>kept per order at the Floor Engine price of ₹399</span></div>
        </div>
      </section>
      <section className="steps">
        {[['1', 'Kitna Bachega?', 'Before signup, see what you really keep per order.'], ['2', 'Floor Engine', 'Breakeven, target floor and a price menu by goal.'], ['3', 'Co-funded launch', 'First 20 orders: Meesho ₹30 + seller ₹20 off.'], ['4', 'Weekly Hisaab', 'Profit in rupees every week, returns explained.'], ['5', 'Mool Mitra alerts', 'Ask-me-first price advice in Hindi on WhatsApp.'], ['6', 'District console', 'Managers spot at-risk sellers and nudge them.']].map(([n, t, d]) => (
          <div key={n} className="step"><span>{n}</span><b>{t}</b><p>{d}</p></div>))}
      </section>
      <section className="howto">
        <h2>3-minute demo</h2>
        <ol>
          <li>Open the <a href="#seller">seller app</a>. Pick a kurti in <b>Kitna Bachega?</b> and see your minimum price.</li>
          <li>Sign up, add the product and open the <b>Floor Engine</b>. Try the ₹-cheap rows: they turn red.</li>
          <li>Go live with the <b>launch offer</b>, then press <b>Next week</b> a few times. Watch Hisaab and accept the Diwali and rival alerts.</li>
          <li>Switch to the <a href="#district">district console</a>: your shop appears at the top, next to 64 simulated sellers.</li>
        </ol>
        <button className="btn ghost" onClick={() => { reset(); location.hash = 'seller'; }}>Start a fresh demo</button>
      </section>
    </main>
  );
}

function SellerPage() {
  const s = useStore();
  const tips: Record<string, string> = {
    calc: 'Answer the dropdowns one by one. The answer card shows the minimum price and what the seller keeps after every deduction.',
    signup: 'Sample details are pre-filled. Tap “Send OTP”, then continue. Use the हिं button to switch the whole app to Hindi.',
    costs: 'The making cost is estimated from the answers; sellers can edit it. Ticking the size chart lowers the minimum price.',
    price: 'Pick a goal or tap any price row. Prices below breakeven turn red and the app blocks listing there. Check “True cost” and “Buyer’s view”.',
    launch: 'Meesho funds ₹30 of a ₹50 launch discount on the first 20 orders only.',
    live: 'Press “Next week”. Around week 3 a rival cuts price; week 4 brings Diwali; week 6 flags returns. Accept or ignore each alert, then check Hisaab and the district console.',
  };
  return (
    <main className="seller-page">
      <SellerApp />
      <aside className="guide">
        <p className="kicker">Presenter guide</p>
        <h2>What to show here</h2>
        <p>{tips[s.step]}</p>
        <div className="guide-k"><span>Seller</span><b>{s.profile.name}</b><span>Week</span><b>{s.week}</b><span>Price</span><b>{s.price ? '₹' + s.price : '—'}</b></div>
        <a className="btn ghost" href="#district">See this seller in the district console →</a>
        <button className="btn ghost" onClick={() => reset()}>Restart demo</button>
      </aside>
    </main>
  );
}
